public class StudentManagement {
    private Student[] students = new Student[150];
    private static int count = 0;

    /**
     * Compare Group.
     * @param s1 First variable.
     * @param s2 Second variable.
     * @return sameGroup
     */
    public static boolean sameGroup(Student s1, Student s2) {
        if (s1.getGroup() == s2.getGroup()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * addStudent.
     * @param newStudent Parameter.
     */
    public void addStudent(Student newStudent) {
        students[count] = newStudent;
        count += 1;
    }

    /**
     * studentsByGroup.
     * @return students By Group
     */
    public String studentsByGroup() {
        String result = "";
        boolean[] res = new boolean[150];
        for (int i = 0; i < count; i++) {
            Student s = students[i];
            if (res[i] == false) {
                result = result.concat(s.getGroup()).concat("\n");
                for (int j = i; j < count; j++) {
                    Student t = students[j];
                    if (t.getGroup().equals(s.getGroup())) {
                        res[j] = true;
                        result = result.concat(t.getInfo()).concat("\n");
                    }
                }
            }
        }
        return result;
    }

    /**
     * remove Student.
     * @param id id of student.
     */
    public void removeStudent(String id) {
        for (int i = 0; i < count; i++) {
            if (students[i].getId().equals(id)) {
                for (int j = i; j < count - 1; j++) {
                    students[j] = students[j + 1];
                }
                count -= 1;
                break;
            }
        }
    }   

    /**
     * main method.
     * @param args Parameter.
     */
    public static void main(String[] args) {
      
    }
}
